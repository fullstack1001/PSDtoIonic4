export const AppRoutes = [
 // { path: '', loadChildren: './pages/ringgames/ringgames.module#ringgamesPageModule' }
 { path: '', loadChildren: './pages/firstscreen/firstscreen.module#firstscreenPageModule' }

];
